import Foundation
import simd

/// Everything the golfer needs to know about one putt.
struct PuttSolution {
    let ball: Vec2
    let hole: Vec2
    let aimPoint: Vec2          // where to start the ball, at the hole's distance
    let path: [Vec2]            // predicted roll
    let holed: Bool
    let distanceFeet: Double
    let aimLeftInches: Double   // + = aim left of the hole, − = right
    let apexInches: Double      // biggest sideways distance from the straight line
    let playsLikeFeet: Double   // hit it as hard as a flat putt of this length
    let elevationInches: Double // + = hole is higher than ball (uphill)
    let alongSlopePercent: Double  // + = uphill toward the hole
    let sideSlopePercent: Double   // + = high side on the LEFT (ball breaks right)
}

/// Rolls virtual balls across the fitted green and finds the line that holes the putt.
struct PuttSolver {
    let surface: GreenSurface
    let stimpFeet: Double

    /// Constant slow-down from grass friction (m/s²), from the Stimpmeter reading:
    /// a ball leaving the Stimpmeter at 1.83 m/s rolls `stimp` feet on flat ground.
    var friction: Double {
        let v = PuttConstants.stimpReleaseSpeed
        return v * v / (2 * stimpFeet * PuttConstants.metersPerFoot)
    }

    struct SimResult {
        let path: [Vec2]
        let holed: Bool
    }

    /// Simulates one putt with small time steps.
    /// A rolling ball feels 5/7 of the downhill pull of gravity (the rest goes into spin),
    /// plus a constant friction force against its direction of travel.
    func simulate(from start: Vec2, velocity startVelocity: Vec2, hole: Vec2, allowCapture: Bool) -> SimResult {
        let dt = 0.002
        let g = PuttConstants.gravity
        let fd = friction
        var p = start
        var v = startVelocity
        var t = 0.0
        var path = [start]
        var holed = false

        while t < 30 {
            let pull = -(5.0 / 7.0) * g * surface.gradient(p)
            let speed = simd_length(v)
            let slopeTooGentleToMove = simd_length(pull) <= fd * 1.2
            var accel = pull
            if speed < 0.005 {
                if slopeTooGentleToMove { break }          // ball has stopped
            } else {
                accel -= fd * (v / speed)
            }
            let newV = v + accel * dt
            if speed >= 0.005 && simd_dot(newV, v) <= 0 && slopeTooGentleToMove { break }
            v = newV
            p += v * dt
            t += dt
            if simd_distance(p, path[path.count - 1]) >= 0.02 { path.append(p) }
            if allowCapture && simd_distance(p, hole) < PuttConstants.holeRadius
                && simd_length(v) < PuttConstants.captureSpeed {
                holed = true
                p = hole
                break
            }
        }
        path.append(p)
        return SimResult(path: path, holed: holed)
    }

    /// Where the roll passes closest to the hole.
    /// - lateral: signed sideways miss (m)
    /// - sToHole: roll distance up to that point (plus the gap if the ball stopped short)
    /// - total: total roll distance
    /// - past: how far it rolled past the hole (negative if short)
    private func closestApproach(path: [Vec2], ball: Vec2, hole: Vec2)
        -> (lateral: Double, sToHole: Double, total: Double, past: Double) {
        let dir = simd_normalize(hole - ball)
        var bestDist = simd_distance(path[0], hole)
        var bestPoint = path[0]
        var bestS = 0.0
        var cumulative = 0.0
        for i in 0..<(path.count - 1) {
            let a = path[i]
            let seg = path[i + 1] - a
            let len = simd_length(seg)
            if len == 0 { continue }
            let t = min(max(simd_dot(hole - a, seg) / (len * len), 0), 1)
            let q = a + t * seg
            let d = simd_distance(q, hole)
            if d < bestDist {
                bestDist = d
                bestPoint = q
                bestS = cumulative + t * len
            }
            cumulative += len
        }
        let miss = bestPoint - hole
        let lateral = dir.x * miss.y - dir.y * miss.x
        if bestS >= cumulative - 1e-6 {
            return (lateral, cumulative + bestDist, cumulative, -bestDist)
        }
        return (lateral, bestS, cumulative, cumulative - bestS)
    }

    func solve(ball: Vec2, hole: Vec2) -> PuttSolution {
        let fd = friction
        let target = PuttConstants.targetPastHole
        let d = hole - ball
        let length = simd_length(d)
        let dir = d / length
        let straightAngle = atan2(d.y, d.x)

        func heading(_ angle: Double) -> Vec2 { Vec2(cos(angle), sin(angle)) }
        func roll(_ angle: Double, _ speed: Double) -> (lateral: Double, path: [Vec2]) {
            let r = simulate(from: ball, velocity: heading(angle) * speed, hole: hole, allowCapture: false)
            return (closestApproach(path: r.path, ball: ball, hole: hole).lateral, r.path)
        }

        // Start with a straight putt at flat-green pace, then correct aim and speed in turns.
        var speed = (2 * fd * (length + target)).squareRoot()
        var angle = straightAngle
        for _ in 0..<20 {
            // Find the aim that passes over the hole at this speed (secant method).
            var a0 = angle
            var a1 = angle + 0.01
            var f0 = roll(a0, speed).lateral
            var (f1, path) = roll(a1, speed)
            for _ in 0..<30 {
                if abs(f1) < 0.002 || f1 == f0 { break }
                var a2 = a1 - f1 * (a1 - a0) / (f1 - f0)
                a2 = min(max(a2, straightAngle - 1), straightAngle + 1)
                a0 = a1
                f0 = f1
                a1 = a2
                (f1, path) = roll(a1, speed)
            }
            angle = a1

            // Adjust speed so it would finish ~16 in past the hole.
            let info = closestApproach(path: path, ball: ball, hole: hole)
            if abs(info.past - target) < 0.02 && abs(info.lateral) < 0.003 { break }
            let ratio = (info.sToHole + target) / max(info.total, 0.05)
            speed *= min(max(ratio, 0.25), 4).squareRoot()
        }

        let final = simulate(from: ball, velocity: heading(angle) * speed, hole: hole, allowCapture: true)
        let aimPoint = ball + heading(angle) * length
        var apex = 0.0
        for p in final.path { apex = max(apex, abs(leftOffset(of: p - ball, from: dir))) }

        var slope = Vec2(0, 0)
        for k in 0...10 { slope += surface.gradient(ball + d * (Double(k) / 10)) }
        slope /= 11

        let inch = PuttConstants.metersPerInch, foot = PuttConstants.metersPerFoot
        return PuttSolution(
            ball: ball,
            hole: hole,
            aimPoint: aimPoint,
            path: final.path,
            holed: final.holed,
            distanceFeet: length / foot,
            aimLeftInches: leftOffset(of: aimPoint - hole, from: dir) / inch,
            apexInches: apex / inch,
            playsLikeFeet: max(speed * speed / (2 * fd) - target, 0) / foot,
            elevationInches: (surface.height(hole) - surface.height(ball)) / inch,
            alongSlopePercent: simd_dot(slope, dir) * 100,
            sideSlopePercent: leftOffset(of: slope, from: dir) * 100
        )
    }
}
