import Foundation
import simd

/// A smooth model of the green's height: h(x, z) as a polynomial (plane, quadratic or cubic).
/// Real greens are smooth, so fitting a smooth surface averages away scan noise
/// (grass blades, shadows, footprints) while keeping the true slopes.
struct GreenSurface {
    let origin: Vec2      // center of the putt; coordinates are normalised around it
    let scale: Double     // meters per normalised unit
    let degree: Int
    let coeffs: [Double]  // always 10 values, unused higher terms are 0

    static func termCount(_ degree: Int) -> Int { degree == 1 ? 3 : (degree == 2 ? 6 : 10) }

    /// Polynomial terms: 1, u, v, u², uv, v², u³, u²v, uv², v³
    static func basis(_ u: Double, _ v: Double) -> [Double] {
        [1, u, v, u * u, u * v, v * v, u * u * u, u * u * v, u * v * v, v * v * v]
    }

    /// Height of the green (meters, ARKit world y) at a point.
    func height(_ p: Vec2) -> Double {
        let u = (p.x - origin.x) / scale, v = (p.y - origin.y) / scale
        let c = coeffs
        return c[0] + c[1] * u + c[2] * v
            + c[3] * u * u + c[4] * u * v + c[5] * v * v
            + c[6] * u * u * u + c[7] * u * u * v + c[8] * u * v * v + c[9] * v * v * v
    }

    /// Slope at a point: (dh/dx, dh/dz), in meters of rise per meter. 0.02 = 2% slope.
    func gradient(_ p: Vec2) -> Vec2 {
        let u = (p.x - origin.x) / scale, v = (p.y - origin.y) / scale
        let c = coeffs
        let dU = c[1] + 2 * c[3] * u + c[4] * v + 3 * c[6] * u * u + 2 * c[7] * u * v + c[8] * v * v
        let dV = c[2] + c[4] * u + 2 * c[5] * v + c[7] * u * u + 2 * c[8] * u * v + 3 * c[9] * v * v
        return Vec2(dU, dV) / scale
    }
}

enum FitError: LocalizedError {
    case tooClose
    case tooFar
    case notEnoughScan(Double)

    var errorDescription: String? {
        switch self {
        case .tooClose:
            return "The ball and hole are too close together. Tap Start Over and place them again."
        case .tooFar:
            return "Putts longer than 50 ft aren't supported yet."
        case .notEnoughScan(let c):
            return "Only \(Int(c * 100))% of the line is scanned. Walk slowly beside the line with the camera pointed at the green."
        }
    }
}

struct SurfaceFit {
    let surface: GreenSurface
    let rmsErrorMM: Double
    let cellCount: Int
    let coverage: Double

    var quality: String {
        let label = rmsErrorMM < 6 ? "Good" : (rmsErrorMM < 12 ? "OK" : "Poor")
        return "\(label) (±\(Int(rmsErrorMM.rounded())) mm)"
    }
}

enum SurfaceFitter {
    static let cellSize = 0.08        // m – scan points are grouped into 8 cm squares
    static let corridor = 0.75        // m – use ground within this distance of the line
    static let minCoverage = 0.6      // fraction of the line that must be scanned

    struct CellKey: Hashable {
        let i: Int
        let j: Int
    }

    /// Groups scan points near the putt line into grid cells (heights per cell).
    static func bin(_ points: [SIMD3<Float>], ball: Vec2, hole: Vec2) -> [CellKey: [Double]] {
        let d = hole - ball
        let len2 = simd_dot(d, d)
        var cells: [CellKey: [Double]] = [:]
        guard len2 > 1e-6 else { return cells }
        let length = len2.squareRoot()
        let tMin = -corridor / length, tMax = 1 + corridor / length
        for p3 in points {
            let p = flat(p3)
            let t = min(max(simd_dot(p - ball, d) / len2, tMin), tMax)
            if simd_distance(p, ball + t * d) > corridor { continue }
            let key = CellKey(i: Int(floor(p.x / cellSize)), j: Int(floor(p.y / cellSize)))
            cells[key, default: []].append(Double(p3.y))
        }
        return cells
    }

    /// Fraction of the ball→hole line that has scan data close to it.
    static func coverage(_ cells: [CellKey: [Double]], ball: Vec2, hole: Vec2) -> Double {
        let length = simd_distance(ball, hole)
        let n = max(Int(length / 0.1), 1)
        var covered = 0
        for k in 0...n {
            let p = ball + (hole - ball) * (Double(k) / Double(n))
            let ci = Int(floor(p.x / cellSize)), cj = Int(floor(p.y / cellSize))
            var found = 0
            for di in -2...2 {
                for dj in -2...2 where cells[CellKey(i: ci + di, j: cj + dj)] != nil {
                    found += 1
                }
            }
            if found >= 3 { covered += 1 }
        }
        return Double(covered) / Double(n + 1)
    }

    /// Fits a smooth surface to the scan, ignoring outliers (feet, the flagstick, the ball).
    static func fit(points: [SIMD3<Float>], ball: Vec2, hole: Vec2) throws -> SurfaceFit {
        let length = simd_distance(ball, hole)
        guard length >= 0.3 else { throw FitError.tooClose }
        guard length <= 15.5 else { throw FitError.tooFar }

        let cells = bin(points, ball: ball, hole: hole)
        let cov = coverage(cells, ball: ball, hole: hole)
        // Short putts get a simpler surface: fewer terms = less chance of inventing bumps.
        let degree = length < 1.5 ? 1 : (length < 4 ? 2 : 3)
        let nTerms = GreenSurface.termCount(degree)
        guard cov >= minCoverage, cells.count >= nTerms * 4 else { throw FitError.notEnoughScan(cov) }

        let origin = (ball + hole) / 2
        let scale = length / 2 + corridor

        struct Row {
            let b: [Double]
            let h: Double
            let w: Double
        }
        let rows: [Row] = cells.map { key, heights in
            let center = Vec2((Double(key.i) + 0.5) * cellSize, (Double(key.j) + 0.5) * cellSize)
            let u = (center.x - origin.x) / scale, v = (center.y - origin.y) / scale
            return Row(b: Array(GreenSurface.basis(u, v).prefix(nTerms)),
                       h: median(heights),
                       w: Double(min(heights.count, 30)))
        }

        var keep = [Bool](repeating: true, count: rows.count)
        var coeffs = [Double](repeating: 0, count: nTerms)
        var residuals = [Double](repeating: 0, count: rows.count)
        for _ in 0..<2 {
            var normal = [[Double]](repeating: [Double](repeating: 0, count: nTerms), count: nTerms)
            var rhs = [Double](repeating: 0, count: nTerms)
            for (row, use) in zip(rows, keep) where use {
                for a in 0..<nTerms {
                    rhs[a] += row.w * row.b[a] * row.h
                    for c in 0..<nTerms { normal[a][c] += row.w * row.b[a] * row.b[c] }
                }
            }
            for a in 1..<nTerms { normal[a][a] += 1e-6 * normal[0][0] }   // tiny smoothing
            guard let solution = solveLinear(normal, rhs) else { throw FitError.notEnoughScan(cov) }
            coeffs = solution
            residuals = rows.map { row in
                var predicted = 0.0
                for a in 0..<nTerms { predicted += row.b[a] * coeffs[a] }
                return row.h - predicted
            }
            var kept: [Double] = []
            for (r, use) in zip(residuals, keep) where use { kept.append(r) }
            let mid = median(kept)
            let mad = median(kept.map { abs($0 - mid) })
            let limit = max(0.01, 3 * 1.4826 * mad)
            keep = residuals.map { abs($0) <= limit }
        }

        var sumSq = 0.0, count = 0
        for (r, use) in zip(residuals, keep) where use {
            sumSq += r * r
            count += 1
        }
        let rms = count > 0 ? (sumSq / Double(count)).squareRoot() : 0
        let padded = coeffs + [Double](repeating: 0, count: 10 - nTerms)
        let surface = GreenSurface(origin: origin, scale: scale, degree: degree, coeffs: padded)
        return SurfaceFit(surface: surface, rmsErrorMM: rms * 1000, cellCount: rows.count, coverage: cov)
    }
}
