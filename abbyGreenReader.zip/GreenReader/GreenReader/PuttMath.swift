import Foundation
import simd

/// A point or direction on the green, seen from above: (x, z) in ARKit world meters.
typealias Vec2 = SIMD2<Double>

enum PuttConstants {
    static let gravity = 9.81                 // m/s²
    static let holeRadius = 0.054             // regulation cup is 4.25 in across
    static let captureSpeed = 1.3             // m/s – faster than this the ball lips out
    static let stimpReleaseSpeed = 1.83       // m/s – speed a ball leaves a Stimpmeter
    static let targetPastHole = 0.40          // m – aim for a putt that would finish ~16 in past
    static let metersPerFoot = 0.3048
    static let metersPerInch = 0.0254
}

/// Horizontal position of a 3D ARKit point.
func flat(_ p: SIMD3<Float>) -> Vec2 { Vec2(Double(p.x), Double(p.z)) }

/// How far `v` points to the golfer's LEFT when facing along `dir`.
/// ARKit world space is x right, y up, z toward the viewer, so the (x, z) plane seen from
/// above is mirrored compared to ordinary math axes – hence the minus sign.
func leftOffset(of v: Vec2, from dir: Vec2) -> Double {
    -(dir.x * v.y - dir.y * v.x)
}

func median(_ values: [Double]) -> Double {
    guard !values.isEmpty else { return 0 }
    let s = values.sorted()
    return s.count % 2 == 1 ? s[s.count / 2] : (s[s.count / 2 - 1] + s[s.count / 2]) / 2
}

/// Solves A·x = b with Gaussian elimination (partial pivoting). Returns nil if singular.
func solveLinear(_ A: [[Double]], _ b: [Double]) -> [Double]? {
    let n = b.count
    var m = A
    var r = b
    for col in 0..<n {
        var pivot = col
        for row in (col + 1)..<max(n, col + 1) where abs(m[row][col]) > abs(m[pivot][col]) {
            pivot = row
        }
        guard abs(m[pivot][col]) > 1e-12 else { return nil }
        if pivot != col {
            m.swapAt(pivot, col)
            r.swapAt(pivot, col)
        }
        for row in (col + 1)..<max(n, col + 1) {
            let f = m[row][col] / m[col][col]
            if f == 0 { continue }
            for k in col..<n { m[row][k] -= f * m[col][k] }
            r[row] -= f * r[col]
        }
    }
    var x = [Double](repeating: 0, count: n)
    for row in stride(from: n - 1, through: 0, by: -1) {
        var s = r[row]
        for k in (row + 1)..<max(n, row + 1) { s -= m[row][k] * x[k] }
        x[row] = s / m[row][row]
    }
    return x
}
