import Foundation
import Combine
import SwiftUI
import UIKit
import ARKit
import RealityKit
import simd

/// Runs the AR session: placing the ball and hole, LiDAR scanning, reading the putt,
/// and drawing the predicted line on the real green.
@MainActor
final class PuttController: ObservableObject {
    enum Phase {
        case placeBall, placeHole, scanning, result
    }

    @Published private(set) var phase: Phase = .placeBall
    @Published private(set) var message = "Stand behind your ball and tap on it."
    @Published private(set) var coverage: Double = 0
    @Published private(set) var solution: PuttSolution?
    @Published private(set) var scanQuality = ""
    @Published private(set) var hasLiDAR = true
    @Published var showMesh = true {
        didSet { updateMeshDisplay() }
    }

    let arView: ARView
    private var ballWorld: SIMD3<Float>?
    private var holeWorld: SIMD3<Float>?
    private var lastFit: SurfaceFit?
    private var started = false
    private let markerRoot: AnchorEntity   // ball and hole markers
    private let lineRoot: AnchorEntity     // the predicted line

    init() {
        arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: false)
        markerRoot = AnchorEntity(world: SIMD3<Float>(0, 0, 0))
        lineRoot = AnchorEntity(world: SIMD3<Float>(0, 0, 0))
    }

    // MARK: - Session

    func start() {
        guard !started else { return }
        started = true
        guard ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) else {
            hasLiDAR = false
            message = "This device has no LiDAR sensor. Green Reader needs an iPhone Pro or iPad Pro (2020 or newer)."
            return
        }
        let config = ARWorldTrackingConfiguration()
        config.worldAlignment = .gravity          // world "up" = opposite of gravity
        config.sceneReconstruction = .mesh        // LiDAR builds a 3D mesh of the green
        config.planeDetection = [.horizontal]
        arView.session.run(config)
        arView.scene.addAnchor(markerRoot)
        arView.scene.addAnchor(lineRoot)
        updateMeshDisplay()
    }

    private func updateMeshDisplay() {
        if showMesh && phase != .result {
            arView.debugOptions.insert(.showSceneUnderstanding)
        } else {
            arView.debugOptions.remove(.showSceneUnderstanding)
        }
    }

    private func setPhase(_ newPhase: Phase) {
        phase = newPhase
        updateMeshDisplay()
    }

    // MARK: - Placing ball and hole

    func handleTap(at point: CGPoint) {
        guard hasLiDAR, phase == .placeBall || phase == .placeHole else { return }
        guard let hit = arView.raycast(from: point, allowing: .estimatedPlane, alignment: .any).first else {
            message = "Couldn't find the ground there. Move the phone slowly so it can see the green, then tap again."
            return
        }
        let c = hit.worldTransform.columns.3
        let position = SIMD3<Float>(c.x, c.y, c.z)

        if phase == .placeBall {
            ballWorld = position
            addMarker(sphereRadius: 0.018, color: .systemBlue, at: position + SIMD3<Float>(0, 0.10, 0))
            message = "Now tap on the hole."
            setPhase(.placeHole)
        } else {
            guard let ball = ballWorld, simd_distance(flat(ball), flat(position)) >= 0.3 else {
                message = "That's too close to the ball. Tap on the hole."
                return
            }
            holeWorld = position
            let pole = ModelEntity(mesh: .generateBox(size: SIMD3<Float>(0.01, 0.6, 0.01)),
                                   materials: [UnlitMaterial(color: .systemRed)])
            pole.position = position + SIMD3<Float>(0, 0.3, 0)
            markerRoot.addChild(pole)
            coverage = 0
            message = "Walk slowly beside the line, pointing the camera at the green between the ball and the hole."
            setPhase(.scanning)
        }
    }

    private func addMarker(sphereRadius: Float, color: UIColor, at position: SIMD3<Float>) {
        let marker = ModelEntity(mesh: .generateSphere(radius: sphereRadius),
                                 materials: [UnlitMaterial(color: color)])
        marker.position = position
        markerRoot.addChild(marker)
    }

    // MARK: - Scanning

    /// All LiDAR mesh vertices, in world coordinates.
    private func meshPoints() -> [SIMD3<Float>] {
        guard let frame = arView.session.currentFrame else { return [] }
        var points: [SIMD3<Float>] = []
        for anchor in frame.anchors {
            guard let mesh = anchor as? ARMeshAnchor else { continue }
            let vertices = mesh.geometry.vertices
            let base = vertices.buffer.contents().advanced(by: vertices.offset)
            points.reserveCapacity(points.count + vertices.count)
            for i in 0..<vertices.count {
                let v = base.advanced(by: vertices.stride * i).assumingMemoryBound(to: Float.self)
                let world = mesh.transform * SIMD4<Float>(v[0], v[1], v[2], 1)
                points.append(SIMD3<Float>(world.x, world.y, world.z))
            }
        }
        return points
    }

    /// Called twice a second by the UI to update the scan progress bar.
    func tick() {
        guard phase == .scanning, let ball = ballWorld, let hole = holeWorld else { return }
        let b = flat(ball), h = flat(hole)
        let cells = SurfaceFitter.bin(meshPoints(), ball: b, hole: h)
        coverage = SurfaceFitter.coverage(cells, ball: b, hole: h)
    }

    // MARK: - Reading the putt

    func readPutt(stimp: Double) {
        guard let ball = ballWorld, let hole = holeWorld else { return }
        do {
            let fit = try SurfaceFitter.fit(points: meshPoints(), ball: flat(ball), hole: flat(hole))
            lastFit = fit
            scanQuality = fit.quality
            setPhase(.result)
            resolve(stimp: stimp)
        } catch {
            message = error.localizedDescription
        }
    }

    /// Re-runs the physics (e.g. after the green speed changes) without re-scanning.
    func resolve(stimp: Double) {
        guard phase == .result, let fit = lastFit, let ball = ballWorld, let hole = holeWorld else { return }
        let solver = PuttSolver(surface: fit.surface, stimpFeet: stimp)
        let result = solver.solve(ball: flat(ball), hole: flat(hole))
        solution = result
        message = "Here's your line. Yellow = the ball's path, white = start line, tall yellow pole = aim point."
        draw(result, on: fit.surface)
    }

    private func draw(_ s: PuttSolution, on surface: GreenSurface) {
        lineRoot.children.removeAll()
        func world(_ p: Vec2, lift: Double = 0.01) -> SIMD3<Float> {
            SIMD3<Float>(Float(p.x), Float(surface.height(p) + lift), Float(p.y))
        }

        // Predicted path of the ball.
        let dotMesh = MeshResource.generateSphere(radius: 0.009)
        let yellow = UnlitMaterial(color: .systemYellow)
        var lastDot: Vec2?
        for p in s.path {
            if let last = lastDot, simd_distance(last, p) < 0.05 { continue }
            let dot = ModelEntity(mesh: dotMesh, materials: [yellow])
            dot.position = world(p)
            lineRoot.addChild(dot)
            lastDot = p
        }

        // Start line: straight from the ball toward the aim point.
        let smallDot = MeshResource.generateSphere(radius: 0.005)
        let white = UnlitMaterial(color: .white)
        let startLength = min(simd_distance(s.ball, s.aimPoint), 1.0)
        let startDir = simd_normalize(s.aimPoint - s.ball)
        var d = 0.05
        while d <= startLength {
            let dot = ModelEntity(mesh: smallDot, materials: [white])
            dot.position = world(s.ball + startDir * d, lift: 0.012)
            lineRoot.addChild(dot)
            d += 0.04
        }

        // Aim pole.
        let pole = ModelEntity(mesh: .generateBox(size: SIMD3<Float>(0.012, 0.5, 0.012)), materials: [yellow])
        pole.position = world(s.aimPoint, lift: 0.25)
        lineRoot.addChild(pole)
        let top = ModelEntity(mesh: .generateSphere(radius: 0.025), materials: [yellow])
        top.position = world(s.aimPoint, lift: 0.5)
        lineRoot.addChild(top)
    }

    // MARK: - Navigation

    func rescan() {
        guard holeWorld != nil else { return }
        lineRoot.children.removeAll()
        solution = nil
        message = "Keep scanning the line, then tap Read Putt again."
        setPhase(.scanning)
    }

    func reset() {
        markerRoot.children.removeAll()
        lineRoot.children.removeAll()
        ballWorld = nil
        holeWorld = nil
        lastFit = nil
        solution = nil
        coverage = 0
        scanQuality = ""
        if hasLiDAR { message = "Stand behind your ball and tap on it." }
        setPhase(.placeBall)
    }
}
