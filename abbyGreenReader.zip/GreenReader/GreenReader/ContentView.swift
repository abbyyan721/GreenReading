import SwiftUI
import Combine
import UIKit
import RealityKit

struct ContentView: View {
    @StateObject private var controller = PuttController()
    @AppStorage("stimp") private var stimp: Double = 10.0
    private let ticker = Timer.publish(every: 0.5, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            ARViewContainer(controller: controller)
                .ignoresSafeArea()

            VStack(spacing: 12) {
                Text(controller.message)
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .padding(12)
                    .frame(maxWidth: .infinity)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))

                Spacer()

                if controller.phase == .result, let solution = controller.solution {
                    ResultCard(solution: solution, quality: controller.scanQuality)
                }
                controls
            }
            .padding()
        }
        .onReceive(ticker) { _ in controller.tick() }
        .onChange(of: stimp) { _, newValue in controller.resolve(stimp: newValue) }
    }

    private var controls: some View {
        VStack(spacing: 10) {
            HStack {
                Text("Green speed (Stimp)")
                Spacer()
                Text(String(format: "%.1f", stimp)).monospacedDigit().bold()
            }
            Slider(value: $stimp, in: 7...14, step: 0.5)

            if controller.phase == .scanning {
                ProgressView(value: controller.coverage) {
                    Text(verbatim: "Line scanned: \(Int(controller.coverage * 100))%")
                        .font(.subheadline)
                }
            }

            HStack {
                Button("Start Over", role: .destructive) { controller.reset() }
                    .buttonStyle(.bordered)
                Spacer()
                if controller.phase == .scanning {
                    Button("Read Putt") { controller.readPutt(stimp: stimp) }
                        .buttonStyle(.borderedProminent)
                        .disabled(controller.coverage < SurfaceFitter.minCoverage)
                } else if controller.phase == .result {
                    Button("Re-scan") { controller.rescan() }
                        .buttonStyle(.borderedProminent)
                }
            }

            Toggle("Show scan mesh", isOn: $controller.showMesh)
                .font(.subheadline)
        }
        .padding()
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}

struct ResultCard: View {
    let solution: PuttSolution
    let quality: String

    private func feet(_ value: Double) -> String {
        value >= 10 ? String(format: "%.0f", value) : String(format: "%.1f", value)
    }

    private var aimText: String {
        let inches = abs(solution.aimLeftInches)
        if inches < 1 { return "Aim at the center of the hole" }
        let side = solution.aimLeftInches > 0 ? "LEFT" : "RIGHT"
        let cups = inches / 4.25
        return "Aim \(Int(inches.rounded())) in \(side) of the hole (\(String(format: "%.1f", cups)) cups)"
    }

    private var elevationText: String {
        let e = solution.elevationInches
        if abs(e) < 0.5 { return "level" }
        return String(format: "%.1f in %@", abs(e), e > 0 ? "uphill" : "downhill")
    }

    private var breakText: String {
        let side = solution.sideSlopePercent
        if abs(side) < 0.2 { return "Almost straight" }
        let direction = side > 0 ? "left-to-right" : "right-to-left"
        return String(format: "Breaks %@ · %.1f%% side slope", direction, abs(side))
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(aimText)
                .font(.title3.bold())
            Text("Hit it like a \(feet(solution.playsLikeFeet)) ft flat putt")
                .font(.headline)
            Divider()
            Label("\(feet(solution.distanceFeet)) ft · \(elevationText)", systemImage: "ruler")
            Label(breakText, systemImage: "arrow.turn.up.right")
            Label("Scan quality: \(quality)", systemImage: "checkmark.seal")
            if !solution.holed {
                Text("Couldn't find a line that drops. Try re-scanning.")
                    .foregroundStyle(.orange)
            }
        }
        .font(.subheadline)
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}

/// Puts the AR camera view into SwiftUI and forwards screen taps to the controller.
struct ARViewContainer: UIViewRepresentable {
    let controller: PuttController

    func makeCoordinator() -> Coordinator { Coordinator(controller: controller) }

    func makeUIView(context: Context) -> ARView {
        let view = controller.arView
        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.tapped(_:)))
        view.addGestureRecognizer(tap)
        controller.start()
        return view
    }

    func updateUIView(_ uiView: ARView, context: Context) {}

    @MainActor
    final class Coordinator: NSObject {
        let controller: PuttController
        init(controller: PuttController) { self.controller = controller }

        @objc func tapped(_ gesture: UITapGestureRecognizer) {
            controller.handleTap(at: gesture.location(in: gesture.view))
        }
    }
}
