# Green Reader v0.1

An iPhone app that scans a putting green with LiDAR, works out the slopes, simulates the roll and draws the putting line on the real green in AR.

## What you need
- A Mac with **Xcode** (free from the Mac App Store)
- An **iPhone Pro / iPad Pro with LiDAR** (iPhone 12 Pro or newer Pro), on iOS 17 or later
- A USB cable for the first install

## Set up the project (about 10 minutes, one time)

1. Open Xcode → **File → New → Project…** → **iOS → App** → Next.
2. Fill in:
   - Product Name: **GreenReader**
   - Team: your Apple ID (Add Account… if it's empty; a free account works)
   - Interface: **SwiftUI**, Language: **Swift**, Storage: None, no tests
3. Save it anywhere (e.g. Desktop).
4. In the left sidebar, **delete** the `ContentView.swift` and `GreenReaderApp.swift` that Xcode made (choose "Move to Trash").
5. Drag all 6 `.swift` files from this folder's `GreenReader` subfolder into the sidebar, onto the yellow **GreenReader** folder. Tick **Copy items if needed** and make sure the GreenReader target is checked.
6. Camera permission: click the blue project icon at the top of the sidebar → **GreenReader** target → **Info** tab → hover over any row, click **+**, choose **Privacy - Camera Usage Description**, and type: `Scans the green to read your putt.`
7. Same target → **General** tab → **Minimum Deployments**: iOS 17.0 or newer.

## Put it on your iPhone
1. Plug in the iPhone and pick it from the device menu at the top of Xcode.
2. On the iPhone, turn on **Settings → Privacy & Security → Developer Mode** (it restarts).
3. Press **▶ Run** in Xcode.
4. The first time, the iPhone may say "Untrusted Developer": go to **Settings → General → VPN & Device Management**, tap your Apple ID, then **Trust**.
5. With a free Apple ID the app stops opening after 7 days. Just press Run again to reinstall.

If Xcode shows red errors, take a screenshot and send it to Claude.

## How to use it
1. Stand behind your ball and **tap the ball** on screen (a blue dot floats above it).
2. **Tap the hole** (a red flagstick appears).
3. **Walk slowly beside the line** with the camera aimed at the green. The colored mesh shows what's been scanned. Wait until "Line scanned" is at least 60% (higher is better).
4. Set the **green speed** (Stimp). Most public courses are 8–10, private clubs 10–12, tour events 12–14.
5. Tap **Read Putt**:
   - **Yellow dots** = the path the ball will roll
   - **White dots** = your start line
   - **Tall yellow pole** = your aim point
   - The card says how far left/right to aim and how hard to hit it ("like a 12 ft flat putt").
6. Move the Stimp slider and the line updates instantly.

## How it works
| Step | File | What it does |
|---|---|---|
| Scan | `PuttController.swift` | ARKit + LiDAR build a 3D mesh; the world is aligned with gravity so "down" is known |
| Clean up | `GreenSurface.swift` | Groups scan points into 8 cm squares, throws out outliers (feet, ball, flagstick) and fits a smooth surface |
| Physics | `PuttSolver.swift` | Rolls virtual balls: 5/7 of gravity's downhill pull + grass friction from the Stimp. Adjusts aim and speed until the ball goes in with pace to finish ~16 in past |
| Display | `PuttController.swift` | Draws the line and aim point in AR |
| Screen | `ContentView.swift` | Buttons, slider and result card |

## Field-testing checklist (please report back)
1. **Floor test (at home):** scan 10 ft across a flat, hard floor. It should say "Almost straight" with a side slope under 0.3%. If it shows more, the phone's tilt sensing has a bias and we'll add a calibration step.
2. **Repeat test:** read the same putt 3 times. Do the aim numbers agree within ~2 in?
3. **Real putts:** on a practice green, read 10–20 putts of 5–20 ft, hit each one at the aim point, and note what happened: in, missed left/right by how much, short/long.
4. Send screenshots plus your notes. That's how we tune it.

> Rules note: USGA/R&A rules ban devices that read greens during a competition round. Use it for practice and casual rounds.
